﻿

namespace PlayersAndMonsters
{
    public class MuseElf : Elf
    {
        public MuseElf(string usernme, int level) : base(usernme, level)
        {
        }
    }
}

﻿

namespace PlayersAndMonsters
{
    public class Elf : Hero
    {
        public Elf(string usernme,int level) : base(usernme,level)
        {

        }
    }
}

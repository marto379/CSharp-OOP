﻿namespace Telephony.Models.Interfaces
{
    public interface IBrowseble
    {
        string BrowseURL(string url);
    }
}

﻿namespace Telephony.Models.IO.Interfaces
{
    public interface IWritter
    {
        void Write(string text);
        void WriteLine(string text);
    }
}

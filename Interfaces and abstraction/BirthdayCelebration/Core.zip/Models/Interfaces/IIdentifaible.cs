﻿
namespace BorderControl.Models.Interfaces
{
    public interface IIdentifaible
    {
        string Id { get; }
    }
}
